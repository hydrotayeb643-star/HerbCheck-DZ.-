HerbCheck DZ V2.0 — Prototype
Features: bilingual Arabic/French UI; multiple shop records; inventory lots; manual storage-condition logs; rule-based operational alerts; scientific herb cards; source registry; printable reports (browser Print > Save as PDF); JSON export/import; local offline-first storage.

Run: open index.html in a modern browser. For installable PWA/offline service worker, host all files on HTTPS and open in Chrome Android, then choose Install/Add to Home Screen.

Data is stored locally in the browser on this device. No cloud sync, authentication, or APK build is included.
Temperature and relative humidity must be measured externally and entered manually. Numeric thresholds are not invented. Alerts do not establish herb safety, detect contaminants, or replace laboratory analysis. Scientific source metadata and rules require expert review before commercial deployment.
