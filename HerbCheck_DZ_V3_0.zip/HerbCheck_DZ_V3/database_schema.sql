-- HerbCheck DZ 3.0: starter schema for Supabase PostgreSQL
-- Run only in a new/test Supabase project after reviewing the schema.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null default 'attar' check (role in ('attar','admin')),
  created_at timestamptz not null default now()
);

create table public.shops (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text,
  owner_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.herb_catalog (
  id bigint generated always as identity primary key,
  common_name_ar text not null,
  scientific_name text not null,
  plant_part text not null
);

create table public.stock_lots (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  herb_id bigint not null references public.herb_catalog(id),
  batch_code text,
  quantity numeric(12,3) not null check (quantity >= 0),
  unit text not null,
  received_on date,
  package_type text,
  created_at timestamptz not null default now()
);

create table public.storage_logs (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  lot_id uuid not null references public.stock_lots(id) on delete cascade,
  recorded_at timestamptz not null default now(),
  temperature_c numeric(6,2),
  relative_humidity_pct numeric(6,2),
  light_exposure text,
  ventilation text,
  package_condition text,
  observations text
);

create table public.references_registry (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  publisher text,
  publication_year integer,
  url text,
  notes text,
  created_at timestamptz not null default now()
);

-- Helper: admin status is derived from authenticated profile.
create or replace function public.is_platform_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.shops enable row level security;
alter table public.herb_catalog enable row level security;
alter table public.stock_lots enable row level security;
alter table public.storage_logs enable row level security;
alter table public.references_registry enable row level security;

-- Users can read their own profile; platform admins can read all profiles.
create policy "profiles_read_self_or_admin" on public.profiles
for select using (id = auth.uid() or public.is_platform_admin());

-- Shop owner sees their own shop; central admin sees all.
create policy "shops_read_owner_or_admin" on public.shops
for select using (owner_id = auth.uid() or public.is_platform_admin());
create policy "shops_admin_insert" on public.shops
for insert with check (public.is_platform_admin());
create policy "shops_admin_update" on public.shops
for update using (public.is_platform_admin()) with check (public.is_platform_admin());

-- Catalog and scientific references are readable by signed-in users.
create policy "catalog_read_authenticated" on public.herb_catalog
for select to authenticated using (true);
create policy "references_read_authenticated" on public.references_registry
for select to authenticated using (true);
create policy "references_admin_manage" on public.references_registry
for all using (public.is_platform_admin()) with check (public.is_platform_admin());

-- Data access follows shop ownership, with central admin oversight.
create policy "lots_read_owner_or_admin" on public.stock_lots
for select using (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
);
create policy "lots_insert_owner_or_admin" on public.stock_lots
for insert with check (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
);
create policy "lots_update_owner_or_admin" on public.stock_lots
for update using (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
) with check (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
);

create policy "logs_read_owner_or_admin" on public.storage_logs
for select using (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
);
create policy "logs_insert_owner_or_admin" on public.storage_logs
for insert with check (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
);
create policy "logs_update_owner_or_admin" on public.storage_logs
for update using (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
) with check (
  public.is_platform_admin() or exists (
    select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()
  )
);

insert into public.herb_catalog (common_name_ar, scientific_name, plant_part) values
('النعناع الفلفلي','Mentha × piperita L.','الأوراق'),
('البابونج الألماني','Matricaria chamomilla L.','الرؤوس الزهرية'),
('الزعتر الشائع','Thymus vulgaris L.','الأجزاء الهوائية'),
('إكليل الجبل','Salvia rosmarinus Spenn.','الأوراق'),
('المريمية','Salvia officinalis L.','الأوراق');
